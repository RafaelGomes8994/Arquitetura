# Processador MIPS Ciclo Único feito em Verilog para a disciplina Arquitetura de Computadores 2024.2
## Pré-requisitos:
- Icarus Verilog
- GTKWave
- GNU Make
## Execução:
Abra um terminal e execute: 
```bash
make all
```
